=== KapsuleHost Migrator ===
Contributors: kapsulehost
Tags: migration, migrate, wordpress, backup, export
Requires at least: 5.0
Tested up to: 7.1
Stable tag: 1.3.0
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Migrate your WordPress site to KapsuleHost, or export your site for manual migration to any host.

== Description ==

Kapsule Migrator does two things:

**1. Export for manual migration (no account required)**
Package your WordPress files and database into downloadable archives and move them anywhere you like. No Kapsule account needed.

**2. Direct migration to KapsuleHost**
Transfer your site directly to KapsuleHost with one click. Connect with a migration token and the plugin handles everything.

= How the direct migration works =

1. Start a migration at kpanel.kapsulehost.com — choose the "Plugin" path
2. Copy your one-time migration token from the Kapsule wizard
3. Install and activate this plugin on your current site
4. Paste your token — the plugin handles everything from there

The plugin scans your site, packages files in chunks (works even on large sites), exports your database, and transfers everything directly to Kapsule. Your current site is never modified.

= How the export works =

1. Install and activate the plugin (no account needed)
2. Go to Kapsule Migrate in your admin menu
3. Click the "Export Site" tab
4. Click "Export Site" — packaging runs in the background
5. Download your files and database archives when ready

= Features =

* Works with any WordPress host (no SSH or FTP credentials required)
* Chunked transfer — handles multi-GB sites without hitting PHP memory limits
* Export mode works without a Kapsule account
* Token-based auth for direct migration — no passwords stored or shared
* wp-config.php excluded from all exports for security
* Self-cleans after migration is confirmed

= Security =

* Your migration token is single-use and expires in 2 hours
* All transfers are encrypted in transit (HTTPS)
* The plugin only reads your site — it never writes to it
* wp-config.php and wp-config-sample.php are never included in exports
* Token and temporary files are deleted after migration completes

== Installation ==

= For direct migration to Kapsule =
1. Start a migration at kpanel.kapsulehost.com/sites/migrate
2. Choose the Plugin path and copy your migration token
3. In your WordPress admin, go to Plugins → Add New → Upload Plugin
4. Upload the zip file and activate
5. Go to Kapsule Migrate in your admin menu
6. Paste your migration token and click Start Migration

= For export / manual migration =
1. Download from kpanel.kapsulehost.com/downloads/kapsule-migrator.zip or install from WordPress.org
2. Activate the plugin
3. Go to Kapsule Migrate in your admin menu
4. Click "Export Site" tab, then "Export Site"
5. Download your archives when packaging completes

== Frequently Asked Questions ==

= Do I need a Kapsule account? =
No. The "Export Site" mode works without any account. You only need a Kapsule account for the direct migration path.

= Will this affect my live site? =
No. The plugin only reads your files and database — it never modifies anything.

= What if the migration fails? =
The plugin will show an error message with details. Contact Kapsule support and we'll sort it out. Your site is completely unaffected.

= Do I need to keep the plugin installed? =
Once migration is complete and you've confirmed your site is live on Kapsule, you can deactivate and delete the plugin.

= What files are excluded from exports? =
wp-config.php and wp-config-sample.php are always excluded. Common cache directories, node_modules, and backup directories are also skipped.

== Screenshots ==

1. The "Migrate to Kapsule" tab — paste your migration token and start a direct transfer to KapsuleHost.
2. The "Export Site" tab — package your site for download without a Kapsule account.
3. Migration running — chunked transfer progress in real time.
4. Export complete — download your files and database archives when packaging finishes.

== Changelog ==

= 1.3.0 =
* Fixed, and it is the reason for this release: this screen used to say "Move complete. Your site is
  on KapsuleHost" the moment the upload finished, with "Database: Copied" printed beside it. The
  upload finishing is not the move finishing. Everything that can go wrong (unpacking your files,
  putting them in place, importing your database, rewriting your addresses, checking the result
  serves) happens afterwards, on our side. One customer read that screen while their database import
  was about to fail.
* The plugin now reports the state of the JOB, read from KapsuleHost, and cannot say a move finished
  until KapsuleHost says it finished. If the move fails, this screen says so, says which step it
  stopped on, and shows what our server actually reported.
* "Database: Copied" is now a fact rather than a word: it says Imported or Not imported, from what
  the import actually did.
* If we cannot reach KapsuleHost to check on your move, the screen says that, instead of showing you
  the last thing it happened to know.
* Your site is still only ever read, never changed, at every one of these steps.

= 1.2.0 =
* The plugin now speaks all 16 languages KapsuleHost sells in, including right-to-left Arabic. Every
  screen, every button and every error message, not just the front page.
* Fixed: choosing "start over" could make the next migration skip files it believed were already
  sent, and report success having transferred nothing.
* Fixed: a dropped connection is now retried in your browser, where you can see it happening, with
  the piece being retried and the time until the next attempt shown. Running out of attempts pauses
  the move rather than failing it, because everything already copied is kept.
* Fixed: resuming a migration no longer rebuilds pieces the server already has.
* Fixed: prepared pieces are now deleted as soon as they are delivered, so migrating no longer needs
  double your site's size in free space.
* Fixed: a migration run from the scheduler uploaded the database under a name the server did not
  recognise, and reported it as a failed upload.
* Rebuilt the interface around what is actually moving: pieces sent, data transferred, files counted.

= 1.0.7 =
* Improved upload reliability: server now tracks which chunks have been received, so interrupted transfers resume correctly without re-uploading complete chunks
* Upload manifest now includes chunk count to improve progress accuracy

= 1.0.6 =
* PharData fallback for PHP hosts without the zip extension (previously only ZipArchive and system tar were tried)
* Added cancel button so in-progress migrations can be cleanly aborted

= 1.0.5 =
* Fixed skip-pattern matching for top-level directories (was incorrectly including some cache dirs)
* Added automated test suite for the packager component

= 1.0.4 =
* WP.org compliance: added capability check on all AJAX endpoints, improved SQL escaping, added text domain, added screenshots

= 1.0.3 =
* Improved accessibility: focus states on interactive elements; mobile-responsive admin CSS

= 1.0.2 =
* Added standalone export mode (no Kapsule account required)
* Dual-distribution: separate CDN and WordPress.org builds to ensure correct update channel

= 1.0.1 =
* Security: wp-config.php and wp-config-sample.php excluded from all exports and migration packages

= 1.0.0 =
* Initial release — direct migration to KapsuleHost
